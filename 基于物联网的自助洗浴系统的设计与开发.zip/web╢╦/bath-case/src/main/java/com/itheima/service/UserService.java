package com.itheima.service;


import com.itheima.mapper.UserMapper;

import com.itheima.pojo.User;
import com.itheima.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class UserService {

    //1.创建工厂对象
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();


    /*
    * 登录方法
    * @param usename
    * @param password
    * */
    public User login(String username,String password){
        //2.获取sqlsession对象
        SqlSession sqlSession = factory.openSession();
        //3.获取usermapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        //4.调用方法
        User user = mapper.select(username,password);

        //5.释放资源
        sqlSession.close();

        return user;
    }


    /*
     * 注册方法
     * @param usename
     * @param password
     * */
    public boolean register(User user){
        //2.获取sqlsession对象
        SqlSession sqlSession = factory.openSession();
        //3.获取usermapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        //4.调用方法
        User u = mapper.selectByUsername(user.getUsername());

        if (u == null){
            //用户名不存在，注册
            mapper.add(user);
            sqlSession.commit();

        }
        sqlSession.close();

        return u == null;



    }
}
