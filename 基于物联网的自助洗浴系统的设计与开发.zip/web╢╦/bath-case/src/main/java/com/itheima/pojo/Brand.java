package com.itheima.pojo;

public class Brand {
    // num 主键
    private Integer num;
    // 创建日期
    private String create_time;
    // 修改日期
    private String update_at;

    // 数据流名
    private String id;
    // 标识字段
    private String uuid;
    // 数据流值
    private String current_value;


    public Brand() {

    }

    public Brand(Integer num, String create_time, String update_at, String id, String uuid, String current_value) {
        this.num = num;
        this.create_time = create_time;
        this.update_at = update_at;
        this.id = id;
        this.uuid = uuid;
        this.current_value = current_value;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getUpdate_at() {
        return update_at;
    }

    public void setUpdate_at(String update_at) {
        this.update_at = update_at;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getCurrent_value() {
        return current_value;
    }

    public void setCurrent_value(String current_value) {
        this.current_value = current_value;
    }

    @Override
    public String toString() {
        return "Brand{" +
                "num=" + num +
                ", create_time='" + create_time + '\'' +
                ", update_at='" + update_at + '\'' +
                ", id='" + id + '\'' +
                ", uuid='" + uuid + '\'' +
                ", current_value='" + current_value + '\'' +
                '}';
    }
}
