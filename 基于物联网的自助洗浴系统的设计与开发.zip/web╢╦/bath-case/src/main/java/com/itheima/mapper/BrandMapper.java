package com.itheima.mapper;

import com.itheima.pojo.Brand;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface BrandMapper {

    /*
    * 查询所有
    * @return
    * */
    @Select("select * from device")
    @ResultMap("brandResultMap")
    List<Brand> selectAll();

/*    @Insert("insert into device values(null,#{)")
    void add(Brand brand);*/



    /*
    * 批量删除
    * @param nums
    * */
    void deleteByNums(@Param("nums") int[] nums);

    /*
    * 根据id删除
    * */
    void deleteByNum(int num);


    /*
    * 分页查询
    * @param begian
    * @param size
    * */
    @Select("select * from device limit #{begin}, #{size}")
    List<Brand> selectByPage(@Param("begin") int begin,@Param("size") int size);

    /*
    * 查询总记录数
    * @return
    * */
    @Select("select count(*) from device ")
    int selectTotalCount();

    /*
     * 分页条件查询
     * @param begian
     * @param size
     * */
    List<Brand> selectByPageAndCondition(@Param("begin") int begin,@Param("size") int size,@Param("brand") Brand brand);

    /*
     * 根据查询总记录数
     * @return
     * */
    int selectTotalCountByCondition(Brand brand);




}
