package com.itheima.util;

import com.itheima.pojo.Brand;

import com.mysql.jdbc.PreparedStatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Jdbcdemo {
    private static Connection getConn() {
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/test";
        String username = "root";
        String password = "mysql";
        Connection conn = null;
        try {
            Class.forName(driver); // classLoader,加载对应驱动
            conn = (Connection) DriverManager.getConnection(url, username,password);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
    public static void insert(Brand brand) {
        Connection conn = getConn();
        PreparedStatement ps = null;
        String sql = "INSERT INTO device (create_time,update_at,id,uuid,current_value)" +
                " VALUES('"+brand.getCreate_time()+"','"+brand.getUpdate_at()+"','"+brand.getId()+"'," +
                "'"+brand.getUuid()+"','"+brand.getCurrent_value()+"')";
        //PreparedStatement ps = conn.prepareStatement(sql);
        try {
            ps = (PreparedStatement) conn.prepareStatement(sql);// 把写好的sql语句传递到数据库，让数据库知道我们要干什么
            int a = ps.executeUpdate();// 这个方法用于改变数据库数据，a代表改变数据库的条数
            if (a > 0) {
                System.out.println("添加成功");
            } else {
                System.out.println("添加失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
